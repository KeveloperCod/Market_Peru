package com.cibertec.dto;

public class ProductoRequest {

	   public String nombre;
	    public Integer idCategoria;
	    public Integer stock;
	    public Double precio;
	
	
	
	
}
