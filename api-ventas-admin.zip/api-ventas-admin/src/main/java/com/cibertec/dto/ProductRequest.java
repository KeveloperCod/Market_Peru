package com.cibertec.dto;

public class ProductRequest {

    public String nombre;
    public Integer idCategoria;
    public Integer stock;
    public double precio;
	public Object esActivo;
	
	
	
}
