package com.cibertec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVentasAdminApplication {

	public static void main(String[] args) {
        SpringApplication.run(ApiVentasAdminApplication.class, args);

        String password = "admin123";
        String encrypted = new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().encode(password);
        System.out.println("Contraseña encriptada: " + encrypted);
    }
}


