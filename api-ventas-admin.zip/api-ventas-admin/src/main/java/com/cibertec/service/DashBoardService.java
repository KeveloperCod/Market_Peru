package com.cibertec.service;

import java.util.Map;

public interface DashBoardService {
    Map<String, Object> getSummary();
}

