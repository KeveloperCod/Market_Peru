package com.cibertec.service;

public interface NumeroDocumentoService {
    String generarNumeroDocumento();
}
