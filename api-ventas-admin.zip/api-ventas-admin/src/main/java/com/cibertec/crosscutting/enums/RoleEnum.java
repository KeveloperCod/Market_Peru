package com.cibertec.crosscutting.enums;

public enum RoleEnum {
}
